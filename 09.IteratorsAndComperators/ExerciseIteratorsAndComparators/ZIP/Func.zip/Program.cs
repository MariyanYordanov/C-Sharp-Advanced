﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ExerciseIteratorsAndComparators
{
    public class Program
    {
        static void Main(string[] args)
        {

            int[] integerElements = Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            Array.Sort(integerElements);

            Console.WriteLine(string.Join(" ",integerElements));
        }
    }
}
