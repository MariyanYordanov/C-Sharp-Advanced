﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static Guild.StartUp;

namespace Guild
{
    public class Guild
    {
        List<Player> roster;
        public string Name { get; set; }
        public int Capacity { get; set; }

        public int Count => roster.Count;

        public Guild(string name, int capacity)
        {
            this.Name = name;
            this.Capacity = capacity;
            roster = new List<Player>();
        }

        public void AddPlayer(Player player)
        {
            if (this.Count < this.Capacity)
            {
                roster.Add(player);
            }
        }

        public bool RemovePlayer(string name)
        {
            var player = roster.FirstOrDefault(x => x.Name == name);
            return roster.Remove(player);
        }

        public void PromotePlayer(string name)
        {
            var player = roster.FirstOrDefault(x => x.Name == name);
            if (player != null)
            {
                if (player.Rank != "Member")
                {
                    roster[roster.IndexOf(player)].Rank = "Member";
                }
            }
        }

        public void DemotePlayer(string name)
        {
            var player = roster.FirstOrDefault(x => x.Name == name);
            if (player != null)
            {
                if (player.Rank != "Trial")
                {
                    roster[roster.IndexOf(player)].Rank = "Trial";
                }
            }
        }

        public Player[] KickPlayersByClass(string playerClass)
        {
            var temp = roster.Where(x => x.Class == playerClass).ToArray();
            roster = roster.Where(x => x.Class != playerClass).ToList();
            return temp;
        }

        public string Report()
        {
            string result = $"Players in the guild: {this.Name}";
            foreach (var item in roster)
            {
                result += Environment.NewLine + item.ToString();
            }
            return result;
        }
    }
}