﻿using System;
using System.Collections.Generic;
using System.Text;

namespace E._02.GenericBoxOfInteger
{
    public class Box<T>
    {
        public List<T> Items;

        public Box()
        {
            Items = new List<T>();
        }

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var item in Items)
            {
                Console.WriteLine($"{typeof(T)}: {item}");
            }
            
            return stringBuilder.ToString();
        }
    }
}
