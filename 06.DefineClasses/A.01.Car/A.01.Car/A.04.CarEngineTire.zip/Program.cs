﻿using System;
using CarManufacturer;

namespace CarManufacturer
{
    public class StartUp
    {
        
        static void Main(string[] args)
        {
            Tire[] tires = new Tire[4]
            {
                new Tire(2019,2.2),
                new Tire(2019,2.2),
                new Tire(2020,2.4),
                new Tire(2020,2.4)
            };

            Engine engine = new Engine(100, 1.6);

            Car car = new Car("Honda", "Civic", 2020, 250, 9, engine, tires);

           
        }
    }
}
