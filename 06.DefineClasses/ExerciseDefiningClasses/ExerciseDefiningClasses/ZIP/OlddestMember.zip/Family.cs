﻿using System.Collections.Generic;

namespace DefiningClasses
{
    public class Family
    {
        List<Person> people = new List<Person>();
        public void AddMember(Person person)
        {
            people.Add(person);
        }

        public Person GetOldestMember()
        {
            int maxAge = int.MinValue;
            string name = "";
            foreach (var person in people)
            {
                if (person.Age > maxAge)
                {
                    maxAge = person.Age;
                    name = person.Name;
                }
            }
            Person olddestPerson = new Person(name, maxAge);
            return olddestPerson;
        }
    }
}
