﻿using System.Collections.Generic;

namespace DefiningClasses
{
    public class Family
    {
        List<Person> people = new List<Person>();
        public void AddMember(Person person)
        {
            people.Add(person);
        }

        public List<Person> GetPersonOver30()
        {
            List<Person> filtradedFamily = new List<Person>();
            foreach (var member in people)
            {
                if (member.Age > 30)
                {
                    Person person = new Person(member.Name, member.Age);
                    filtradedFamily.Add(person);
                }
            }

            return filtradedFamily;
        }

        public Person GetOldestMember()
        {
            int maxAge = int.MinValue;
            string name = "";
            foreach (var person in people)
            {
                if (person.Age > maxAge)
                {
                    maxAge = person.Age;
                    name = person.Name;
                }
            }
            Person olddestPerson = new Person(name, maxAge);
            return olddestPerson;
        }
    }
}
